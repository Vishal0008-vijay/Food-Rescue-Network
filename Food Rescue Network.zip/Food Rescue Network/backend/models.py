
from sqlalchemy import Column, Integer, String, Text, DateTime, TIMESTAMP, ForeignKey, Enum
from sqlalchemy.sql import func
from database import Base


class User(Base):
    __tablename__ = "users"

    user_id = Column(Integer, primary_key=True, autoincrement=True)
    full_name = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    password = Column(String(255), nullable=False)
    phone = Column(String(15))
    role = Column(Enum("donor", "ngo", "volunteer", "admin"), nullable=False)
    address = Column(Text)
    created_at = Column(TIMESTAMP, server_default=func.current_timestamp())


class Donation(Base):
    __tablename__ = "donations"

    donation_id = Column(Integer, primary_key=True, autoincrement=True)
    donor_id = Column(Integer, ForeignKey("users.user_id"), nullable=False)
    food_name = Column(String(100), nullable=False)
    food_description = Column(Text)
    quantity = Column(Integer, nullable=False)
    food_type = Column(String(50))
    prepared_at = Column(DateTime)
    expiry_at = Column(DateTime)
    pickup_address = Column(Text, nullable=False)
    status = Column(
        Enum("available", "requested", "collected", "delivered", "expired"),
        default="available"
    )
    created_at = Column(TIMESTAMP, server_default=func.current_timestamp())


class Request(Base):
    __tablename__ = "requests"

    request_id = Column(Integer, primary_key=True, autoincrement=True)
    ngo_id = Column(Integer, ForeignKey("users.user_id"), nullable=False)
    donation_id = Column(Integer, ForeignKey("donations.donation_id"), nullable=False)
    requested_quantity = Column(Integer, nullable=False)
    request_message = Column(Text)
    status = Column(
        Enum("pending", "approved", "rejected", "completed"),
        default="pending"
    )
    requested_at = Column(TIMESTAMP, server_default=func.current_timestamp())


class Delivery(Base):
    __tablename__ = "deliveries"

    delivery_id = Column(Integer, primary_key=True, autoincrement=True)
    request_id = Column(Integer, ForeignKey("requests.request_id"), nullable=False)
    volunteer_id = Column(Integer, ForeignKey("users.user_id"), nullable=False)
    pickup_time = Column(DateTime)
    delivery_time = Column(DateTime)
    delivery_status = Column(
        Enum("assigned", "picked_up", "in_transit", "delivered", "cancelled"),
        default="assigned"
    )
    delivery_notes = Column(Text)
    created_at = Column(TIMESTAMP, server_default=func.current_timestamp())
