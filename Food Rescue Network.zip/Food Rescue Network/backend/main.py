from datetime import datetime
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session, sessionmaker
from pwdlib import PasswordHash
from sqlalchemy import text

from database import engine
from models import User, Donation, Request, Delivery


app = FastAPI(title="Food Rescue Network API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:5500",
        "http://localhost:5500",
        "http://127.0.0.1:8000"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

password_hash = PasswordHash.recommended()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# PYDANTIC MODELS

class UserRegister(BaseModel):
    full_name: str
    email: EmailStr
    password: str = Field(min_length=8)
    role: str
    phone: str | None = None
    address: str | None = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class DonationCreate(BaseModel):
    donor_id: int
    food_name: str
    food_description: str | None = None
    quantity: int = Field(gt=0)
    food_type: str | None = None
    prepared_at: datetime | None = None
    expiry_at: datetime
    pickup_address: str


class FoodRequestCreate(BaseModel):
    ngo_id: int
    donation_id: int
    requested_quantity: int = Field(gt=0)
    request_message: str | None = None


class RequestDecision(BaseModel):
    donor_id: int
    decision: str


class DeliveryAssign(BaseModel):
    donor_id: int
    volunteer_id: int
    request_id: int


class DeliveryStatusUpdate(BaseModel):
    volunteer_id: int
    delivery_status: str
    delivery_notes: str | None = None


# HOME AND HEALTH

@app.get("/")
def home():
    return {
        "message": "Welcome to Food Rescue Network API",
        "status": "Running"
    }


@app.get("/health")
def health():
    return {
        "status": "Success",
        "message": "Backend is running"
    }


@app.get("/health/db")
def database_health(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        return {
            "database": "Connected",
            "status": "Success",
            "message": "MySQL connection established successfully"
        }
    except Exception:
        raise HTTPException(
            status_code=500,
            detail="Database connection failed"
        )


# USER REGISTRATION

@app.post("/register")
def register(user_data: UserRegister, db: Session = Depends(get_db)):
    allowed_roles = ["donor", "ngo", "volunteer"]

    if user_data.role not in allowed_roles:
        raise HTTPException(status_code=400, detail="Invalid role")

    existing_user = db.query(User).filter(
        User.email == user_data.email
    ).first()

    if existing_user:
        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )

    new_user = User(
        full_name=user_data.full_name,
        email=user_data.email,
        password=password_hash.hash(user_data.password),
        role=user_data.role,
        phone=user_data.phone,
        address=user_data.address
    )

    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return {
        "message": "Registration successful",
        "user_id": new_user.user_id,
        "full_name": new_user.full_name,
        "email": new_user.email,
        "role": new_user.role
    }


# USER LOGIN

@app.post("/login")
def login(login_data: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(
        User.email == login_data.email
    ).first()

    if not user or not password_hash.verify(
        login_data.password,
        user.password
    ):
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password"
        )

    return {
        "message": "Login successful",
        "user_id": user.user_id,
        "full_name": user.full_name,
        "email": user.email,
        "role": user.role
    }


# GET REGISTERED VOLUNTEERS

@app.get("/volunteers")
def get_volunteers(db: Session = Depends(get_db)):
    volunteers = db.query(User).filter(
        User.role == "volunteer"
    ).order_by(User.full_name.asc()).all()

    return [
        {
            "user_id": volunteer.user_id,
            "full_name": volunteer.full_name,
            "email": volunteer.email
        }
        for volunteer in volunteers
    ]


# FOOD DONATIONS

@app.post("/donations")
def create_donation(
    donation_data: DonationCreate,
    db: Session = Depends(get_db)
):
    donor = db.query(User).filter(
        User.user_id == donation_data.donor_id
    ).first()

    if not donor or donor.role != "donor":
        raise HTTPException(status_code=404, detail="Donor not found")

    if donation_data.expiry_at <= datetime.now():
        raise HTTPException(
            status_code=400,
            detail="Expiry time must be in the future"
        )

    donation = Donation(
        donor_id=donation_data.donor_id,
        food_name=donation_data.food_name,
        food_description=donation_data.food_description,
        quantity=donation_data.quantity,
        food_type=donation_data.food_type,
        prepared_at=donation_data.prepared_at,
        expiry_at=donation_data.expiry_at,
        pickup_address=donation_data.pickup_address,
        status="available"
    )

    db.add(donation)
    db.commit()
    db.refresh(donation)

    return {
        "message": "Food donation added successfully",
        "donation_id": donation.donation_id,
        "food_name": donation.food_name,
        "quantity": donation.quantity,
        "status": donation.status
    }


@app.get("/donations/donor/{donor_id}")
def get_donor_donations(
    donor_id: int,
    db: Session = Depends(get_db)
):
    donations = db.query(Donation).filter(
        Donation.donor_id == donor_id
    ).order_by(Donation.donation_id.desc()).all()

    return [
        {
            "donation_id": item.donation_id,
            "donor_id": item.donor_id,
            "food_name": item.food_name,
            "food_description": item.food_description,
            "quantity": item.quantity,
            "food_type": item.food_type,
            "prepared_at": item.prepared_at,
            "expiry_at": item.expiry_at,
            "pickup_address": item.pickup_address,
            "status": item.status,
            "created_at": item.created_at
        }
        for item in donations
    ]


@app.get("/donations/available")
def get_available_donations(db: Session = Depends(get_db)):
    donations = db.query(Donation).filter(
        Donation.status == "available",
        Donation.quantity > 0,
        Donation.expiry_at > datetime.now()
    ).order_by(Donation.donation_id.desc()).all()

    return [
        {
            "donation_id": item.donation_id,
            "donor_id": item.donor_id,
            "food_name": item.food_name,
            "food_description": item.food_description,
            "quantity": item.quantity,
            "food_type": item.food_type,
            "prepared_at": item.prepared_at,
            "expiry_at": item.expiry_at,
            "pickup_address": item.pickup_address,
            "status": item.status
        }
        for item in donations
    ]


# NGO FOOD REQUESTS

@app.post("/requests")
def create_food_request(
    request_data: FoodRequestCreate,
    db: Session = Depends(get_db)
):
    ngo = db.query(User).filter(
        User.user_id == request_data.ngo_id
    ).first()

    if not ngo or ngo.role != "ngo":
        raise HTTPException(status_code=404, detail="NGO not found")

    donation = db.query(Donation).filter(
        Donation.donation_id == request_data.donation_id
    ).with_for_update().first()

    if not donation:
        raise HTTPException(status_code=404, detail="Donation not found")

    if donation.status != "available" or donation.quantity <= 0:
        raise HTTPException(
            status_code=400,
            detail="Donation is not available"
        )

    if donation.expiry_at <= datetime.now():
        raise HTTPException(status_code=400, detail="Donation has expired")

    if request_data.requested_quantity > donation.quantity:
        raise HTTPException(
            status_code=400,
            detail=f"Only {donation.quantity} portions are available"
        )

    food_request = Request(
        ngo_id=request_data.ngo_id,
        donation_id=request_data.donation_id,
        requested_quantity=request_data.requested_quantity,
        request_message=request_data.request_message,
        status="pending"
    )

    db.add(food_request)
    db.commit()
    db.refresh(food_request)

    return {
        "message": "Food request submitted successfully",
        "request_id": food_request.request_id,
        "requested_quantity": food_request.requested_quantity,
        "status": food_request.status
    }


@app.get("/requests/ngo/{ngo_id}")
def get_ngo_requests(ngo_id: int, db: Session = Depends(get_db)):
    requests = db.query(Request).filter(
        Request.ngo_id == ngo_id
    ).order_by(Request.request_id.desc()).all()

    return [
        {
            "request_id": item.request_id,
            "ngo_id": item.ngo_id,
            "donation_id": item.donation_id,
            "requested_quantity": item.requested_quantity,
            "request_message": item.request_message,
            "status": item.status,
            "requested_at": item.requested_at
        }
        for item in requests
    ]


@app.get("/requests/donor/{donor_id}")
def get_donor_requests(donor_id: int, db: Session = Depends(get_db)):
    requests = (
        db.query(Request)
        .join(Donation, Request.donation_id == Donation.donation_id)
        .filter(Donation.donor_id == donor_id)
        .order_by(Request.request_id.desc())
        .all()
    )

    return [
        {
            "request_id": item.request_id,
            "ngo_id": item.ngo_id,
            "donation_id": item.donation_id,
            "requested_quantity": item.requested_quantity,
            "request_message": item.request_message,
            "status": item.status,
            "requested_at": item.requested_at
        }
        for item in requests
    ]


# DONOR APPROVES OR REJECTS REQUEST

@app.post("/requests/{request_id}/decision")
def decide_request(
    request_id: int,
    decision_data: RequestDecision,
    db: Session = Depends(get_db)
):
    if decision_data.decision not in ["approved", "rejected"]:
        raise HTTPException(
            status_code=400,
            detail="Decision must be approved or rejected"
        )

    try:
        food_request = db.query(Request).filter(
            Request.request_id == request_id
        ).with_for_update().first()

        if not food_request:
            raise HTTPException(status_code=404, detail="Request not found")

        donation = db.query(Donation).filter(
            Donation.donation_id == food_request.donation_id
        ).with_for_update().first()

        if not donation:
            raise HTTPException(status_code=404, detail="Donation not found")

        if donation.donor_id != decision_data.donor_id:
            raise HTTPException(
                status_code=403,
                detail="You are not allowed to manage this request"
            )

        if food_request.status != "pending":
            raise HTTPException(
                status_code=400,
                detail="This request has already been processed"
            )

        if decision_data.decision == "approved":
            if donation.status != "available":
                raise HTTPException(
                    status_code=400,
                    detail="This donation is no longer available"
                )

            if food_request.requested_quantity > donation.quantity:
                raise HTTPException(
                    status_code=400,
                    detail=f"Only {donation.quantity} portions remain"
                )

            donation.quantity -= food_request.requested_quantity
            food_request.status = "approved"

            if donation.quantity > 0:
                donation.status = "available"
            else:
                donation.status = "requested"

        else:
            food_request.status = "rejected"

        db.commit()
        db.refresh(food_request)
        db.refresh(donation)

        return {
            "message": f"Request {food_request.status} successfully",
            "request_id": food_request.request_id,
            "request_status": food_request.status,
            "donation_id": donation.donation_id,
            "remaining_quantity": donation.quantity,
            "donation_status": donation.status
        }

    except HTTPException:
        db.rollback()
        raise
    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail="Could not process the request"
        )


# VOLUNTEER DELIVERY FEATURES

# ASSIGN VOLUNTEER

@app.post("/deliveries/assign")
def assign_volunteer(
    assignment: DeliveryAssign,
    db: Session = Depends(get_db)
):
    donor = db.query(User).filter(
        User.user_id == assignment.donor_id
    ).first()

    if not donor or donor.role != "donor":
        raise HTTPException(status_code=404, detail="Donor not found")

    volunteer = db.query(User).filter(
        User.user_id == assignment.volunteer_id
    ).first()

    if not volunteer or volunteer.role != "volunteer":
        raise HTTPException(status_code=404, detail="Volunteer not found")

    food_request = db.query(Request).filter(
        Request.request_id == assignment.request_id
    ).first()

    if not food_request:
        raise HTTPException(status_code=404, detail="Request not found")

    donation = db.query(Donation).filter(
        Donation.donation_id == food_request.donation_id
    ).first()

    if not donation or donation.donor_id != assignment.donor_id:
        raise HTTPException(
            status_code=403,
            detail="You are not allowed to assign this request"
        )

    if food_request.status != "approved":
        raise HTTPException(
            status_code=400,
            detail="Only approved requests can be assigned"
        )

    existing_delivery = db.query(Delivery).filter(
        Delivery.request_id == food_request.request_id
    ).first()

    if existing_delivery:
        raise HTTPException(
            status_code=400,
            detail="A volunteer has already been assigned to this request"
        )

    delivery = Delivery(
        request_id=food_request.request_id,
        volunteer_id=volunteer.user_id,
        delivery_status="assigned"
    )

    try:
        db.add(delivery)
        db.commit()
        db.refresh(delivery)
    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail="Could not assign volunteer. Please check the database."
        )

    return {
        "message": "Volunteer assigned successfully",
        "delivery_id": delivery.delivery_id,
        "request_id": delivery.request_id,
        "volunteer_id": delivery.volunteer_id,
        "delivery_status": delivery.delivery_status
    }


# VOLUNTEER DELIVERY LIST

@app.get("/deliveries/volunteer/{volunteer_id}")
def get_volunteer_deliveries(
    volunteer_id: int,
    db: Session = Depends(get_db)
):
    volunteer = db.query(User).filter(
        User.user_id == volunteer_id,
        User.role == "volunteer"
    ).first()

    if not volunteer:
        raise HTTPException(status_code=404, detail="Volunteer not found")

    deliveries = db.query(Delivery).filter(
        Delivery.volunteer_id == volunteer_id
    ).order_by(Delivery.delivery_id.desc()).all()

    results = []

    for item in deliveries:
        food_request = db.query(Request).filter(
            Request.request_id == item.request_id
        ).first()

        donation = db.query(Donation).filter(
            Donation.donation_id == food_request.donation_id
        ).first()

        results.append({
            "delivery_id": item.delivery_id,
            "request_id": item.request_id,
            "volunteer_id": item.volunteer_id,
            "food_name": donation.food_name,
            "quantity": food_request.requested_quantity,
            "pickup_address": donation.pickup_address,
            "delivery_status": item.delivery_status,
            "pickup_time": item.pickup_time,
            "delivery_time": item.delivery_time,
            "delivery_notes": item.delivery_notes
        })

    return results


# UPDATE DELIVERY STATUS

@app.patch("/deliveries/{delivery_id}/status")
def update_delivery_status(
    delivery_id: int,
    status_data: DeliveryStatusUpdate,
    db: Session = Depends(get_db)
):
    allowed_statuses = [
        "picked_up",
        "in_transit",
        "delivered",
        "cancelled"
    ]

    if status_data.delivery_status not in allowed_statuses:
        raise HTTPException(
            status_code=400,
            detail="Invalid delivery status"
        )

    delivery = db.query(Delivery).filter(
        Delivery.delivery_id == delivery_id
    ).first()

    if not delivery:
        raise HTTPException(status_code=404, detail="Delivery not found")

    if delivery.volunteer_id != status_data.volunteer_id:
        raise HTTPException(
            status_code=403,
            detail="You are not assigned to this delivery"
        )

    if delivery.delivery_status in ["delivered", "cancelled"]:
        raise HTTPException(
            status_code=400,
            detail="This delivery is already closed"
        )

    if status_data.delivery_status == "in_transit":
        if delivery.delivery_status != "picked_up":
            raise HTTPException(
                status_code=400,
                detail="Food must be picked up before going in transit"
            )

    if status_data.delivery_status == "delivered":
        if delivery.delivery_status not in ["picked_up", "in_transit"]:
            raise HTTPException(
                status_code=400,
                detail="Food must be picked up before delivery"
            )

    if status_data.delivery_status == "picked_up":
        if delivery.delivery_status != "assigned":
            raise HTTPException(
                status_code=400,
                detail="This delivery cannot be marked as picked up"
            )

        delivery.pickup_time = datetime.now()

    if status_data.delivery_status == "delivered":
        delivery.delivery_time = datetime.now()

    delivery.delivery_status = status_data.delivery_status

    if status_data.delivery_notes is not None:
        delivery.delivery_notes = status_data.delivery_notes

    db.commit()
    db.refresh(delivery)

    return {
        "message": "Delivery status updated successfully",
        "delivery_id": delivery.delivery_id,
        "delivery_status": delivery.delivery_status,
        "pickup_time": delivery.pickup_time,
        "delivery_time": delivery.delivery_time
    }


# TRACK REQUEST DELIVERY

@app.get("/deliveries/request/{request_id}")
def track_request_delivery(
    request_id: int,
    db: Session = Depends(get_db)
):
    food_request = db.query(Request).filter(
        Request.request_id == request_id
    ).first()

    if not food_request:
        raise HTTPException(status_code=404, detail="Request not found")

    delivery = db.query(Delivery).filter(
        Delivery.request_id == request_id
    ).first()

    if not delivery:
        return {
            "message": "No volunteer has been assigned yet",
            "request_id": request_id,
            "request_status": food_request.status,
            "delivery": None
        }

    volunteer = db.query(User).filter(
        User.user_id == delivery.volunteer_id
    ).first()

    return {
        "request_id": request_id,
        "request_status": food_request.status,
        "delivery_id": delivery.delivery_id,
        "volunteer_id": delivery.volunteer_id,
        "volunteer_name": volunteer.full_name,
        "delivery_status": delivery.delivery_status,
        "pickup_time": delivery.pickup_time,
        "delivery_time": delivery.delivery_time,
        "delivery_notes": delivery.delivery_notes
    }


# NGO DELIVERY LIST

@app.get("/deliveries/ngo/{ngo_id}")
def get_ngo_deliveries(
    ngo_id: int,
    db: Session = Depends(get_db)
):
    ngo = db.query(User).filter(
        User.user_id == ngo_id,
        User.role == "ngo"
    ).first()

    if not ngo:
        raise HTTPException(status_code=404, detail="NGO not found")

    requests = db.query(Request).filter(
        Request.ngo_id == ngo_id
    ).all()

    results = []

    for food_request in requests:
        delivery = db.query(Delivery).filter(
            Delivery.request_id == food_request.request_id
        ).first()

        if delivery:
            volunteer = db.query(User).filter(
                User.user_id == delivery.volunteer_id
            ).first()

            donation = db.query(Donation).filter(
                Donation.donation_id == food_request.donation_id
            ).first()

            results.append({
                "request_id": food_request.request_id,
                "food_name": donation.food_name,
                "requested_quantity": food_request.requested_quantity,
                "volunteer_name": volunteer.full_name,
                "delivery_status": delivery.delivery_status,
                "pickup_time": delivery.pickup_time,
                "delivery_time": delivery.delivery_time
            })

    return results


# DONOR DELIVERY LIST

@app.get("/deliveries/donor/{donor_id}")
def get_donor_deliveries(
    donor_id: int,
    db: Session = Depends(get_db)
):
    donor = db.query(User).filter(
        User.user_id == donor_id,
        User.role == "donor"
    ).first()

    if not donor:
        raise HTTPException(status_code=404, detail="Donor not found")

    requests = (
        db.query(Request)
        .join(Donation, Request.donation_id == Donation.donation_id)
        .filter(Donation.donor_id == donor_id)
        .all()
    )

    results = []

    for food_request in requests:
        delivery = db.query(Delivery).filter(
            Delivery.request_id == food_request.request_id
        ).first()

        if delivery:
            volunteer = db.query(User).filter(
                User.user_id == delivery.volunteer_id
            ).first()

            donation = db.query(Donation).filter(
                Donation.donation_id == food_request.donation_id
            ).first()

            results.append({
                "request_id": food_request.request_id,
                "food_name": donation.food_name,
                "requested_quantity": food_request.requested_quantity,
                "volunteer_name": volunteer.full_name,
                "delivery_status": delivery.delivery_status,
                "pickup_time": delivery.pickup_time,
                "delivery_time": delivery.delivery_time
            })

    return results